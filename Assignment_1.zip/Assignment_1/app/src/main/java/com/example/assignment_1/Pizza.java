package com.example.assignment_1;

public class Pizza {
    double pizza_price;
    double pepperoni_price = 0;
    double chicken_price = 0;
    double mushroom_price = 0;
    double beef_price = 0;
    double broccoli_price = 0;
    double extra_cheese = 0;
    double delivery_price =0;

    public Pizza() {
    }

    public double getPizza_price() {
        return pizza_price;
    }

    public void setPizza_price(double pizza_price) {
        this.pizza_price = pizza_price;
    }

    public double getPepperoni_price() {
        return pepperoni_price;
    }

    public void setPepperoni_price(double pepperoni_price) {
        this.pepperoni_price = pepperoni_price;
    }

    public double getChicken_price() {
        return chicken_price;
    }

    public void setChicken_price(double chicken_price) {
        this.chicken_price = chicken_price;
    }

    public double getMushroom_price() {
        return mushroom_price;
    }

    public void setMushroom_price(double mushroom_price) {
        this.mushroom_price = mushroom_price;
    }

    public double getBeef_price() {
        return beef_price;
    }

    public void setBeef_price(double beef_price) {
        this.beef_price = beef_price;
    }

    public double getBroccoli_price() {
        return broccoli_price;
    }

    public void setBroccoli_price(double broccoli_price) {
        this.broccoli_price = broccoli_price;
    }

    public double getExtra_cheese() {
        return extra_cheese;
    }

    public void setExtra_cheese(double extra_cheese) {
        this.extra_cheese = extra_cheese;
    }
    public double getDelivery_price(){
        return delivery_price;
    }
    public void setDelivery_price(double delivery_price){
        this.delivery_price = delivery_price;
    }

}
