package com.example.assignment_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
//creates variables
  Pizza pizza;
TextView Total;
double Total_price;
private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

button = (Button)findViewById(R.id.button);
button.setOnClickListener(new View.OnClickListener() {//opens the confirmation activity
    @Override
    public void onClick(View v) {
        openMainActivity2();
    }
});


pizza = new Pizza();
Total =findViewById(R.id.Total);

    }

    public void radioClicked(View view) {//creates price total based on selection
        boolean checked = ((RadioButton) view) .isChecked();

        switch(view.getId()){
            case R.id.smallButton:
            if(checked)
                pizza.setPizza_price(5.50);
            break;

            case R.id.mediumButton:
                if(checked)
                    pizza.setPizza_price(7.99);
                break;

            case R.id.largeButton:
                if(checked)
                    pizza.setPizza_price(10.50);
                break;

            case R.id.xlargeButton:
                if(checked)
                    pizza.setPizza_price(12.99);
                break;
        }
        Total.setText("Total Price:$ " + pizza.getPizza_price());

    }

    public void onCheckboxClicked(View view) {
        boolean checked =((CheckBox)   view) .isChecked();

        switch (view.getId()){

            case R.id.checkBox:
                if(checked)
                    pizza.setPepperoni_price(2);
                else
                    pizza.setPepperoni_price(0);
                break;
            case R.id.checkBox2:
                if(checked)
                    pizza.setChicken_price(2);
                else
                    pizza.setChicken_price(0);
                break;
            case R.id.checkBox3:
                if(checked)
                    pizza.setBeef_price(2);
                else
                    pizza.setBeef_price(0);
                break;

            case R.id.checkBox4:
                if(checked)
                    pizza.setMushroom_price(0.99);
                else
                    pizza.setMushroom_price(0);
                break;
            case R.id.checkBox5:
                if(checked)
                    pizza.setBroccoli_price(0.99);
                else
                    pizza.setBroccoli_price(0);
                break;
            case R.id.checkBox6:
                if(checked)
                    pizza.setExtra_cheese(5);
                else
                    pizza.setExtra_cheese(0);
                break;
                }
          Total.setText("Total Price:$ " +calculate_Total());

    }
    private double calculate_Total(){//calculates the total amount
        Total_price = pizza.getPizza_price()+ pizza.getBeef_price()+pizza.getBroccoli_price()+pizza.getChicken_price()+pizza.getPepperoni_price()+pizza.getExtra_cheese()+pizza.getMushroom_price()+pizza.getDelivery_price();
        return Total_price;
    }

    public void onSwitchClicked(View view) {
        boolean checked =((Switch)   view) .isChecked();
        switch (view.getId()){
            case R.id.delivery:
                if(checked)
                    pizza.setDelivery_price(5);
                else
                    pizza.setDelivery_price(0);
        }
        Total.setText("Total Price:$ "+calculate_Total());
    }

    public void openMainActivity2(){
        Intent intent= new Intent(this,MainActivity2.class );
   startActivity(intent);
    }



}